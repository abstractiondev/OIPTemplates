Bootstrap as-is package (some version). NO CUSTOMIZATIONS!
docs is not used, you can safely remove it or leave in place
ico is not used but is here as a reference for you